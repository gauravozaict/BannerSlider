<?php

namespace Icreative\LoyaltyProgram\Controller\Adminhtml\Tier;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Icreative\LoyaltyProgram\Model\TiersFactory;
use Icreative\LoyaltyProgram\Model\TierReassignService;

class Save extends Action
{
    public const ADMIN_RESOURCE = 'Icreative_LoyaltyProgram::tier';

    private const ALLOWED_FIELDS = [
        'loyalty_tier_id',
        'loyalty_tier_name',
        'discount_amount',
        'usage_limit',
        'min_lifetime_spend',
        'status',
    ];

    protected TiersFactory $tierFactory;
    private TierReassignService $tierReassignService;

    public function __construct(
        Context $context,
        TiersFactory $tierFactory,
        TierReassignService $tierReassignService
    ) {
        parent::__construct($context);
        $this->tierFactory         = $tierFactory;
        $this->tierReassignService = $tierReassignService;
    }

    public function execute()
    {
        $postData = $this->getRequest()->getPostValue();

        if (empty($postData)) {
            $this->messageManager->addErrorMessage(__('No data received.'));
            return $this->_redirect('*/*/');;
        }

        try {
            $data = $this->flattenPostData($postData);

            if (isset($data['image'])) {
                $data['image'] = $this->resolveImageValue($data['image']);
            }

            $data = array_intersect_key($data, array_flip(self::ALLOWED_FIELDS));

            $validationErrors = $this->validateData($data);
            if ($validationErrors) {
                foreach ($validationErrors as $error) {
                    $this->messageManager->addErrorMessage($error);
                }
                return $this->redirectBack($data);
            }

            $data = $this->castScalars($data);

            $model = $this->tierFactory->create();

            // Capture state BEFORE saving so we can detect a status transition.
            $previousTierName    = '';
            $wasActiveBeforeSave = false;

            if (!empty($data['loyalty_tier_id'])) {
                $model->load((int)$data['loyalty_tier_id']);
                if (!$model->getId()) {
                    $this->messageManager->addErrorMessage(__('This tier no longer exists.'));
                    return $this->_redirect('*/*/');;
                }
                $previousTierName    = (string) $model->getData('loyalty_tier_name');
                $wasActiveBeforeSave = ((int) $model->getData('status') === 1);
            }

            $model->setData($data);
            $model->save();

            // ── Status-change reassignment ────────────────────────────────────
            $newStatus          = (int) ($data['status'] ?? 1);
            $savedName          = (string) ($data['loyalty_tier_name'] ?? $previousTierName);
            $tierNameToReassign = $previousTierName ?: $savedName;

            if ($tierNameToReassign !== '') {

                // DISABLE: active tier → inactive
                if ($wasActiveBeforeSave && $newStatus === 0) {
                    $this->tierReassignService->reassignCustomersFromTier($tierNameToReassign);
                    $this->messageManager->addNoticeMessage(__(
                        'Tier "%1" was disabled. Affected customers have been automatically reassigned to the nearest lower active tier.',
                        $tierNameToReassign
                    ));
                }

                // RE-ENABLE: inactive tier → active
                if (!$wasActiveBeforeSave && $newStatus === 1) {
                    $count = $this->tierReassignService->reassignCustomersToReenabledTier($tierNameToReassign);
                    if ($count > 0) {
                        $this->messageManager->addNoticeMessage(__(
                            'Tier "%1" was re-enabled. %2 customer(s) whose spend qualifies have been automatically reassigned back to this tier.',
                            $tierNameToReassign,
                            $count
                        ));
                    } else {
                        $this->messageManager->addNoticeMessage(__(
                            'Tier "%1" was re-enabled. No customers currently qualify for reassignment to this tier.',
                            $tierNameToReassign
                        ));
                    }
                }
            }
            // ─────────────────────────────────────────────────────────────────

            $this->messageManager->addSuccessMessage(__('Tier has been saved successfully.'));

            if (!empty($data['loyalty_tier_id'])) {
                return $this->_redirect('*/*/edit', ['loyalty_tier_id' => $model->getId()]);
            }

            return $this->_redirect('*/*/');;

        } catch (\Exception $e) {
            $this->messageManager->addErrorMessage(__('Could not save Tier: %1', $e->getMessage()));
            return $this->_redirect('*/*/');;
        }
    }

    private function validateData(array &$data): array
    {
        $errors = [];

        if (isset($data['loyalty_tier_id']) && $data['loyalty_tier_id'] !== '') {
            if (!$this->isWholeNumber($data['loyalty_tier_id']) || (int)$data['loyalty_tier_id'] <= 0) {
                $errors[] = __('Invalid tier ID.');
            }
        }

        $tierName = isset($data['loyalty_tier_name']) ? trim((string)$data['loyalty_tier_name']) : '';
        $data['loyalty_tier_name'] = $tierName;
        if ($tierName === '') {
            $errors[] = __('Tier Name is required.');
        } elseif ($tierName !== strip_tags($tierName)) {
            $errors[] = __('Tier Name cannot contain HTML tags.');
        } elseif (mb_strlen($tierName) > 255) {
            $errors[] = __('Tier Name cannot be longer than 255 characters.');
        }

        if (!$this->isWholeNumber($data['discount_amount'] ?? null)) {
            $errors[] = __('Discount Percentage must be a whole number.');
        } else {
            $discountAmount = (int)$data['discount_amount'];
            if ($discountAmount < 1 || $discountAmount > 100) {
                $errors[] = __('Discount Percentage must be between 1 and 100.');
            } else {
                $data['discount_amount'] = $discountAmount;
            }
        }

        if (!$this->isWholeNumber($data['usage_limit'] ?? null)) {
            $errors[] = __('Usage Limit must be a whole number. Use 0 for unlimited.');
        } else {
            $usageLimit = (int)$data['usage_limit'];
            if ($usageLimit > 2147483647) {
                $errors[] = __('Usage Limit is too large.');
            } else {
                $data['usage_limit'] = $usageLimit;
            }
        }

        if (!$this->isWholeNumber($data['min_lifetime_spend'] ?? null)) {
            $errors[] = __('Minimum Spend must be a whole number greater than or equal to 0.');
        } else {
            $minimumSpend = (int)$data['min_lifetime_spend'];
            if ($minimumSpend > 2147483647) {
                $errors[] = __('Minimum Spend is too large.');
            } else {
                $data['min_lifetime_spend'] = $minimumSpend;
            }
        }

        if (!isset($data['status']) || !in_array((string)$data['status'], ['0', '1'], true)) {
            $errors[] = __('Status must be Active or Inactive.');
        } else {
            $data['status'] = (int)$data['status'];
        }

        return $errors;
    }

    private function isWholeNumber(mixed $value): bool
    {
        if (is_int($value)) {
            return $value >= 0;
        }

        if (!is_string($value) && !is_numeric($value)) {
            return false;
        }

        return preg_match('/^\d+$/', trim((string)$value)) === 1;
    }

    private function redirectBack(array $data)
    {
        if (!empty($data['loyalty_tier_id']) && $this->isWholeNumber($data['loyalty_tier_id'])) {
            return $this->_redirect('*/*/edit', ['loyalty_tier_id' => (int)$data['loyalty_tier_id']]);
        }

        return $this->_redirect('*/*/new');
    }

    private function flattenPostData(array $postData): array
    {
        $flat = [];
        foreach ($postData as $key => $value) {
            if (is_array($value) && $this->isAssoc($value)) {
                if (!isset($value['name']) && !isset($value['url'])) {
                    foreach ($value as $fieldKey => $fieldValue) {
                        $flat[$fieldKey] = $fieldValue;
                    }
                    continue;
                }
            }
            $flat[$key] = $value;
        }
        return $flat;
    }

    private function resolveImageValue(mixed $imageData): string
    {
        if (is_string($imageData)) {
            return $imageData;
        }

        if (is_array($imageData)) {
            if (empty($imageData)) {
                return '';
            }
            $first = reset($imageData);
            if (is_array($first)) {
                return $first['name'] ?? $first['file'] ?? '';
            }
            return (string)$first;
        }

        return '';
    }

    private function castScalars(array $data): array
    {
        foreach ($data as $key => $value) {
            if (is_array($value)) {
                $data[$key] = json_encode($value);
            } elseif ($value === null || $value === '') {
                $data[$key] = null;
            }
        }
        return $data;
    }

    private function isAssoc(array $arr): bool
    {
        return array_keys($arr) !== range(0, count($arr) - 1);
    }
}
