<?php

namespace Icreative\LoyaltyProgram\Controller\Adminhtml\Tier;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Ui\Component\MassAction\Filter;
use Icreative\LoyaltyProgram\Model\ResourceModel\Tiers\CollectionFactory;
use Icreative\LoyaltyProgram\Model\TierReassignService;

class MassDelete extends Action
{
    protected $filter;
    protected $collectionFactory;
    private TierReassignService $tierReassignService;

    public function __construct(
        Context $context,
        Filter $filter,
        CollectionFactory $collectionFactory,
        TierReassignService $tierReassignService
    ) {
        $this->filter              = $filter;
        $this->collectionFactory   = $collectionFactory;
        $this->tierReassignService = $tierReassignService;
        parent::__construct($context);
    }

    public function execute()
    {
        $collection = $this->filter->getCollection($this->collectionFactory->create());
        $count      = 0;

        foreach ($collection as $item) {
            $tierName = (string) $item->getData('loyalty_tier_name');

            // Reassign affected customers BEFORE deleting so the fallback
            // query can still read other active tiers from the database.
            if ($tierName !== '') {
                $this->tierReassignService->reassignCustomersFromTier($tierName);
            }

            $item->delete();
            $count++;
        }

        $this->messageManager->addSuccessMessage(
            __('A total of %1 record(s) have been deleted. Affected customers were automatically reassigned to their nearest lower active tier.', $count)
        );
        return $this->resultRedirectFactory->create()->setPath('*/*/index');
    }
}
