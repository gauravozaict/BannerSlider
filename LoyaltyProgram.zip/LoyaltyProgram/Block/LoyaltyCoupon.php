<?php

namespace Icreative\LoyaltyProgram\Block;

use Icreative\LoyaltyProgram\Model\LoyaltyCouponService;
use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Customer\Model\Session as CustomerSession;
use Magento\Framework\View\Element\Template;

class LoyaltyCoupon extends Template
{
    private $customerSession;
    private $checkoutSession;
    private $loyaltyCouponService;

    public function __construct(
        Template\Context $context,
        CustomerSession $customerSession,
        CheckoutSession $checkoutSession,
        LoyaltyCouponService $loyaltyCouponService,
        array $data = []
    ) {
        $this->customerSession = $customerSession;
        $this->checkoutSession = $checkoutSession;
        $this->loyaltyCouponService = $loyaltyCouponService;
        parent::__construct($context, $data);
    }

    public function getCouponCode(): string
    {
        if (!$this->customerSession->isLoggedIn()) {
            return '';
        }

        $quote = $this->checkoutSession->getQuote();

        return (string) $this->loyaltyCouponService->getCouponCodeForCustomer(
            (int) $this->customerSession->getCustomerId(),
            (int) $quote->getStore()->getWebsiteId(),
            (int) $quote->getCustomerGroupId()
        );
    }

    public function shouldRemoveLoyaltyCoupon(): bool
    {
        $quote = $this->checkoutSession->getQuote();
        $couponCode = (string) $quote->getCouponCode();

        return $this->loyaltyCouponService->isLoyaltyCoupon($couponCode) && $this->getCouponCode() === '';
    }
}
