<?php

namespace Icreative\LoyaltyProgram\Block\Cart\Total;

use Magento\Framework\View\Element\Template;
use Magento\Quote\Model\Quote\Address\Total;

class CustomDiscount extends \Magento\Checkout\Block\Total\DefaultTotal
{

    public function getTotal(): ?Total
    {
        $totals = $this->getTotals();
        if (isset($totals['customdiscount'])) {
            return $totals['customdiscount'];
        }
        return null;
    }

    public function getDiscountAmount(): float
    {
        $total = $this->getTotal();
        return $total ? (float) $total->getValue() : 0.0;
    }

    public function getLabel(): string
    {
        $total = $this->getTotal();
        return $total ? (string) $total->getTitle() : (string) __('Loyalty Discount');
    }

    public function getFormattedDiscount(): string
    {
        $amount = $this->getDiscountAmount();
        if ($amount >= 0) {
            return '';
        }
        return $this->priceCurrency->format($amount, false);
    }
   
    public function canDisplay(): bool
    {
        return $this->getDiscountAmount() < 0;
    }
}
