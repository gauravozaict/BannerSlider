<?php
/**
 * DecreaseLifetimeSpend observer.
 *
 * Fires: sales_order_creditmemo_save_after
 *
 * When a refund (credit memo) is issued:
 *  1. Subtracts the refunded grand total from the customer's lifetime spend.
 *  2. Re-assigns the tier (customer may drop to a lower tier after refund).
 *  3. Removes the usage record for the refunded order so the monthly
 *     quota is restored.
 */

namespace Icreative\LoyaltyProgram\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Framework\App\ResourceConnection;
use Psr\Log\LoggerInterface;

class DecreaseLifetimeSpend implements ObserverInterface
{
    protected $customerRepository;
    protected $resource;
    protected $logger;
    protected $assignTier;

    public function __construct(
        CustomerRepositoryInterface $customerRepository,
        ResourceConnection $resource,
        LoggerInterface $logger,
        AssignTier $assignTier
    ) {
        $this->customerRepository = $customerRepository;
        $this->resource           = $resource;
        $this->logger             = $logger;
        $this->assignTier         = $assignTier;
    }

    public function execute(Observer $observer): void
    {
        /** @var \Magento\Sales\Model\Order\Creditmemo $creditmemo */
        $creditmemo = $observer->getEvent()->getCreditmemo();
        $order      = $creditmemo->getOrder();
        $customerId = (int) $order->getCustomerId();

        if (!$customerId) {
            return;
        }

        try {
            $customer     = $this->customerRepository->getById($customerId);
            $attr         = $customer->getCustomAttribute('lifetime_spend');
            $currentSpend = $attr ? (float) $attr->getValue() : 0.0;

            $refundAmount = (float) $creditmemo->getGrandTotal();
            $newSpend     = max(0.0, $currentSpend - $refundAmount);

            // ── 1. Update lifetime spend ──────────────────────────────────
            $customer->setCustomAttribute('lifetime_spend', $newSpend);
            $this->customerRepository->save($customer);

            // ── 2. Re-assign tier ─────────────────────────────────────────
            $this->assignTier->assignTierBasedOnSpend($customerId, $newSpend);

            // ── 3. Remove usage record for this order (restores quota) ────
            $connection = $this->resource->getConnection();
            $usageTable = $this->resource->getTableName('loyalty_discount_usage');
            $connection->delete($usageTable, ['order_id = ?' => (int) $order->getId()]);

            $this->logger->info(sprintf(
                'LoyaltyProgram: Refund processed for customer %d. Spend %.2f → %.2f',
                $customerId,
                $currentSpend,
                $newSpend
            ));
        } catch (\Exception $e) {
            $this->logger->error('LoyaltyProgram DecreaseLifetimeSpend error: ' . $e->getMessage());
        }
    }
}
