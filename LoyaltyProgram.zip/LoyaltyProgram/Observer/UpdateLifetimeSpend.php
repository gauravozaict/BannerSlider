<?php
/**
 * UpdateLifetimeSpend observer.
 *
 * Fires: sales_order_save_after
 *
 * When an order reaches STATE_COMPLETE:
 *  1. Re-calculates the customer's total lifetime spend from all complete orders.
 *  2. Saves the updated lifetime_spend customer attribute.
 *  3. Re-assigns the loyalty tier via AssignTier.
 *  4. If the completed order carried a loyalty discount, records one usage row
 *     in loyalty_discount_usage for this month's quota tracking.
 *
 * STATE_PROCESSING orders do NOT count toward lifetime spend — they haven't
 * been confirmed as revenue yet. Adjust the state check below if your store
 * considers processing = complete.
 */

namespace Icreative\LoyaltyProgram\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Framework\App\ResourceConnection;
use Magento\Sales\Model\ResourceModel\Order\CollectionFactory as OrderCollectionFactory;
use Psr\Log\LoggerInterface;

class UpdateLifetimeSpend implements ObserverInterface
{
    protected $customerRepository;
    protected $orderCollectionFactory;
    protected $resource;
    protected $logger;
    protected $assignTier;

    public function __construct(
        CustomerRepositoryInterface $customerRepository,
        OrderCollectionFactory $orderCollectionFactory,
        ResourceConnection $resource,
        LoggerInterface $logger,
        AssignTier $assignTier
    ) {
        $this->customerRepository     = $customerRepository;
        $this->orderCollectionFactory = $orderCollectionFactory;
        $this->resource               = $resource;
        $this->logger                 = $logger;
        $this->assignTier             = $assignTier;
    }

    public function execute(Observer $observer): void
    {
        /** @var \Magento\Sales\Model\Order $order */
        $order      = $observer->getEvent()->getOrder();
        $quote      = $observer->getEvent()->getQuote();
        if (!$order && $observer->getEvent()->getOrders()) {
            $orders = $observer->getEvent()->getOrders();
            $order = is_array($orders) ? reset($orders) : null;
        }
        if (!$order) {
            return;
        }

        $customerId = (int) $order->getCustomerId();

        if (!$customerId) {
            return; // guest order — nothing to update
        }

        try {
            if ($quote) {
                $this->recordQuoteUsageIfApplicable($quote, $order, $customerId);
                $this->updateUsageAttributes($customerId);
                return;
            }

            // Only act when order is freshly completed.
            if ($order->getState() !== \Magento\Sales\Model\Order::STATE_COMPLETE) {
                return;
            }

            // Only act once (avoid re-running on subsequent saves of the same order).
            if (!$order->dataHasChangedFor('state')) {
                return;
            }

            // ── 1. Recalculate lifetime spend ──────────────────────────────
            $totalSpend = $this->calculateLifetimeSpend($customerId);

            // ── 2. Persist lifetime_spend on customer ──────────────────────
            $customer = $this->customerRepository->getById($customerId);
            $customer->setCustomAttribute('lifetime_spend', $totalSpend);
            $this->customerRepository->save($customer);

            // ── 3. Re-assign tier based on new spend ──────────────────────
            $this->assignTier->assignTierBasedOnSpend($customerId, $totalSpend);

            // ── 4. Record discount usage if this order used loyalty discount ─
            $this->recordUsageIfApplicable($order, $customerId);
            $this->updateUsageAttributes($customerId);

        } catch (\Exception $e) {
            $this->logger->error('LoyaltyProgram UpdateLifetimeSpend error: ' . $e->getMessage());
        }
    }

    /**
     * Sum grand_total of all STATE_COMPLETE orders for this customer.
     */
    private function calculateLifetimeSpend(int $customerId): float
    {
        $collection = $this->orderCollectionFactory->create();
        $collection->addFieldToFilter('customer_id', $customerId)
                   ->addFieldToFilter('state', \Magento\Sales\Model\Order::STATE_COMPLETE);

        $total = 0.0;
        foreach ($collection as $completedOrder) {
            $total += (float) $completedOrder->getGrandTotal();
        }

        return $total;
    }

    /**
     * If the order had a loyalty discount applied, insert one row into
     * loyalty_discount_usage so this month's usage quota is correctly counted.
     * Idempotent: skips if a row for this order already exists.
     */
    private function recordUsageIfApplicable(\Magento\Sales\Model\Order $order, int $customerId): void
    {
        // Detect loyalty discount: discount_description contains "Program" and "Discount"
        $desc = (string) $order->getDiscountDescription();
        if (!str_contains($desc, 'Program') || !str_contains($desc, 'Discount')) {
            return;
        }

        $discountAmount = abs((float) $order->getDiscountAmount());
        if ($discountAmount <= 0) {
            return;
        }

        $connection  = $this->resource->getConnection();
        $usageTable  = $this->resource->getTableName('loyalty_discount_usage');

        // Idempotency check
        $exists = $connection->fetchOne(
            $connection->select()
                ->from($usageTable, ['COUNT(*)'])
                ->where('order_id = ?', (int) $order->getId())
        );

        if ($exists) {
            return;
        }

        // Derive tier name from description e.g. "Gold Program 10% Discount" → "Gold"
        $tierName = $this->extractTierName($desc);

        $connection->insert($usageTable, [
            'customer_id'     => $customerId,
            'order_id'        => (int) $order->getId(),
            'tier_name'       => $tierName,
            'discount_amount' => $discountAmount,
            'created_at'      => date('Y-m-d H:i:s'),
        ]);

        $this->logger->info(sprintf(
            'LoyaltyProgram: Usage recorded — customer %d, order %d, tier "%s", discount %.2f',
            $customerId,
            $order->getId(),
            $tierName,
            $discountAmount
        ));
    }

    private function recordQuoteUsageIfApplicable(
        \Magento\Quote\Model\Quote $quote,
        \Magento\Sales\Model\Order $order,
        int $customerId
    ): void {
        $discountAmount = abs($this->getSalesRuleLoyaltyDiscountAmount($order));
        if ($discountAmount <= 0) {
            return;
        }

        $connection = $this->resource->getConnection();
        $usageTable = $this->resource->getTableName('loyalty_discount_usage');

        $exists = $connection->fetchOne(
            $connection->select()
                ->from($usageTable, ['COUNT(*)'])
                ->where('order_id = ?', (int) $order->getId())
        );

        if ($exists) {
            return;
        }

        $tierName = $this->extractTierNameFromOrder($order, $customerId);

        $connection->insert($usageTable, [
            'customer_id'     => $customerId,
            'order_id'        => (int) $order->getId(),
            'tier_name'       => $tierName,
            'discount_amount' => $discountAmount,
            'created_at'      => date('Y-m-d H:i:s'),
        ]);

        $this->logger->info(sprintf(
            'LoyaltyProgram: Quote usage recorded — customer %d, order %d, tier "%s", discount %.2f',
            $customerId,
            $order->getId(),
            $tierName,
            $discountAmount
        ));
    }

    private function updateUsageAttributes(int $customerId): void
    {
        $customer = $this->customerRepository->getById($customerId);
        $customer->setCustomAttribute('loyalty_discount_used', $this->getThisMonthUsageCount($customerId));
        $customer->setCustomAttribute('loyalty_discount_total_limit', $this->getCurrentUsageLimit($customer));
        $this->customerRepository->save($customer);
    }

    private function getThisMonthUsageCount(int $customerId): int
    {
        $connection = $this->resource->getConnection();
        $usageTable = $this->resource->getTableName('loyalty_discount_usage');

        return (int) $connection->fetchOne(
            $connection->select()
                ->from($usageTable, ['COUNT(*)'])
                ->where('customer_id = ?', $customerId)
                ->where('created_at >= ?', date('Y-m-01 00:00:00'))
                ->where('created_at <= ?', date('Y-m-t 23:59:59'))
        );
    }

    private function getCurrentUsageLimit(\Magento\Customer\Api\Data\CustomerInterface $customer): int
    {
        $tierName = '';
        $tierAttribute = $customer->getCustomAttribute('custom_customer_attribute');
        if ($tierAttribute) {
            $tierName = trim((string) $tierAttribute->getValue());
        }

        if (!$tierName) {
            return 0;
        }

        $connection = $this->resource->getConnection();
        $tierTable = $this->resource->getTableName('loyalty_tiers');

        return (int) $connection->fetchOne(
            $connection->select()
                ->from($tierTable, ['usage_limit'])
                ->where('loyalty_tier_name = ?', $tierName)
                ->where('status = ?', 1)
                ->limit(1)
        );
    }

    private function extractTierNameFromOrder(\Magento\Sales\Model\Order $order, int $customerId): string
    {
        $description = (string) $order->getDiscountDescription();
        $tierName = $description ? $this->extractTierName($description) : '';
        if ($tierName && $tierName !== 'Unknown') {
            return $tierName;
        }

        try {
            $customer = $this->customerRepository->getById($customerId);
            $tierAttribute = $customer->getCustomAttribute('custom_customer_attribute');
            if ($tierAttribute && $tierAttribute->getValue()) {
                return trim((string) $tierAttribute->getValue());
            }
        } catch (\Exception $e) {
            $this->logger->error('LoyaltyProgram extractTierNameFromOrder error: ' . $e->getMessage());
        }

        return 'Unknown';
    }

    private function getSalesRuleLoyaltyDiscountAmount(\Magento\Sales\Model\Order $order): float
    {
        $couponCode = (string) $order->getCouponCode();
        if (!str_starts_with($couponCode, 'LOYAL_')) {
            return 0.0;
        }

        return (float) $order->getDiscountAmount();
    }

    /**
     * Extracts "Gold" from "Gold Program 10% Discount".
     */
    private function extractTierName(string $description): string
    {
        if (preg_match('/^(.+?)\s+Program\s+\d+%\s+Discount$/i', $description, $m)) {
            return trim($m[1]);
        }
        return 'Unknown';
    }
}
