<?php
/**
 * AssignTier observer.
 *
 * Fires on:
 *  - customer_customer_authenticated  (every login)
 *  - customer_register_success        (new registration)
 *
 * Looks up the highest loyalty tier whose min_lifetime_spend the customer
 * has met and saves it as the 'custom_customer_attribute' on the customer.
 * If no tier matches (spend too low) the attribute is cleared so no
 * discount is applied in error.
 */

namespace Icreative\LoyaltyProgram\Observer;

use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Framework\App\ResourceConnection;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Psr\Log\LoggerInterface;

class AssignTier implements ObserverInterface
{
    protected $customerRepository;
    protected $resource;
    protected $logger;

    public function __construct(
        CustomerRepositoryInterface $customerRepository,
        ResourceConnection $resource,
        LoggerInterface $logger
    ) {
        $this->customerRepository = $customerRepository;
        $this->resource           = $resource;
        $this->logger             = $logger;
    }

    public function execute(Observer $observer): void
    {
        // Both events expose the customer differently.
        $customer = $observer->getEvent()->getCustomer()
            ?? $observer->getEvent()->getData('customer');

        if (!$customer || !$customer->getId()) {
            return;
        }

        try {
            $lifetimeSpend = 0;
            $attr = $customer->getCustomAttribute('lifetime_spend');
            if ($attr) {
                $lifetimeSpend = (float) $attr->getValue();
            }

            $this->assignTierBasedOnSpend($customer->getId(), $lifetimeSpend);
        } catch (\Exception $e) {
            $this->logger->error('LoyaltyProgram AssignTier error: ' . $e->getMessage());
        }
    }

    /**
     * Finds the best matching tier and persists it on the customer.
     * Clears the attribute if no tier matches (spend too low).
     *
     * @param int   $customerId
     * @param float $lifetimeSpend
     */
    public function assignTierBasedOnSpend(int $customerId, float $lifetimeSpend): void
    {
        $connection = $this->resource->getConnection();
        $tierTable  = $this->resource->getTableName('loyalty_tiers');

        // Best matching tier = highest min_lifetime_spend that is still <= customer spend
        $select = $connection->select()
            ->from($tierTable)
            ->where('min_lifetime_spend <= ?', $lifetimeSpend)
            ->where('status = ?', 1)
            ->order('min_lifetime_spend DESC')
            ->limit(1);

        $tier = $connection->fetchRow($select);

        $customer = $this->customerRepository->getById($customerId);
        $customer->setCustomAttribute(
            'custom_customer_attribute',
            $tier ? $tier['loyalty_tier_name'] : ''
        );
        $this->customerRepository->save($customer);

        if ($tier) {
            $this->logger->info(sprintf(
                'LoyaltyProgram: Customer %d assigned to tier "%s" (spend: %.2f)',
                $customerId,
                $tier['loyalty_tier_name'],
                $lifetimeSpend
            ));
        }
    }
}
