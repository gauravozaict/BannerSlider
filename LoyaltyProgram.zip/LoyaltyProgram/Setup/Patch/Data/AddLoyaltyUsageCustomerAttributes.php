<?php
namespace Icreative\LoyaltyProgram\Setup\Patch\Data;

use Magento\Customer\Model\Customer;
use Magento\Customer\Setup\CustomerSetupFactory;
use Magento\Eav\Model\Entity\Attribute\SetFactory as AttributeSetFactory;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup\Patch\DataPatchInterface;

class AddLoyaltyUsageCustomerAttributes implements DataPatchInterface
{
    private $moduleDataSetup;
    private $customerSetupFactory;
    private $attributeSetFactory;

    public function __construct(
        ModuleDataSetupInterface $moduleDataSetup,
        CustomerSetupFactory $customerSetupFactory,
        AttributeSetFactory $attributeSetFactory
    ) {
        $this->moduleDataSetup = $moduleDataSetup;
        $this->customerSetupFactory = $customerSetupFactory;
        $this->attributeSetFactory = $attributeSetFactory;
    }

    public function apply()
    {
        $this->moduleDataSetup->getConnection()->startSetup();

        $customerSetup = $this->customerSetupFactory->create(['setup' => $this->moduleDataSetup]);
        $customerEntity = $customerSetup->getEavConfig()->getEntityType(Customer::ENTITY);
        $attributeSetId = $customerEntity->getDefaultAttributeSetId();
        $attributeSet = $this->attributeSetFactory->create();
        $attributeGroupId = $attributeSet->getDefaultGroupId($attributeSetId);

        foreach ($this->getAttributes() as $attributeCode => $attributeData) {
            $attribute = $customerSetup->getEavConfig()->getAttribute(Customer::ENTITY, $attributeCode);
            if (!$attribute || !$attribute->getId()) {
                $customerSetup->addAttribute(Customer::ENTITY, $attributeCode, $attributeData);
                $attribute = $customerSetup->getEavConfig()->getAttribute(Customer::ENTITY, $attributeCode);
            } else {
                $attribute->addData($attributeData);
            }

            $attribute->addData([
                'attribute_set_id' => $attributeSetId,
                'attribute_group_id' => $attributeGroupId,
                'used_in_forms' => ['adminhtml_customer'],
            ]);
            $attribute->save();
        }

        $this->moduleDataSetup->getConnection()->endSetup();
    }

    private function getAttributes(): array
    {
        return [
            'loyalty_discount_used' => [
                'type' => 'int',
                'label' => 'Loyalty Discount Used',
                'input' => 'text',
                'required' => false,
                'visible' => true,
                'user_defined' => true,
                'is_used_in_grid' => true,
                'is_visible_in_grid' => true,
                'is_filterable_in_grid' => true,
                'position' => 1001,
                'system' => 0,
                'default' => 0,
            ],
            'loyalty_discount_total_limit' => [
                'type' => 'int',
                'label' => 'Loyalty Discount Total Limit',
                'input' => 'text',
                'required' => false,
                'visible' => true,
                'user_defined' => true,
                'is_used_in_grid' => true,
                'is_visible_in_grid' => true,
                'is_filterable_in_grid' => true,
                'position' => 1002,
                'system' => 0,
                'default' => 0,
            ],
        ];
    }

    public static function getDependencies()
    {
        return [
            CustomerAttribute::class,
        ];
    }

    public function getAliases()
    {
        return [];
    }
}
