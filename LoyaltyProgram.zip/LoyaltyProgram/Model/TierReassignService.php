<?php
/**
 * TierReassignService
 *
 * Handles two symmetrical scenarios triggered by admin status changes:
 *
 * DISABLE (status 0):
 *   Finds every customer currently assigned to the disabled tier and moves
 *   them to the nearest lower active tier (highest active tier whose
 *   min_lifetime_spend is below the disabled tier's threshold).
 *   If no lower active tier exists the customer attribute is cleared.
 *
 * RE-ENABLE (status 1):
 *   Finds every customer who was previously pushed DOWN to a lower tier
 *   because this tier was disabled, and now qualifies for the re-enabled tier
 *   based on their lifetime_spend. Those customers are moved back UP to the
 *   re-enabled tier.
 *
 *   "Qualifies" means: customer's lifetime_spend >= re-enabled tier's
 *   min_lifetime_spend AND the customer's current tier has a lower
 *   min_lifetime_spend than the re-enabled tier (i.e. they were demoted).
 */

namespace Icreative\LoyaltyProgram\Model;

use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\App\ResourceConnection;
use Psr\Log\LoggerInterface;

class TierReassignService
{
    private $customerRepository;
    private $searchCriteriaBuilder;
    private $resource;
    private $logger;

    public function __construct(
        CustomerRepositoryInterface $customerRepository,
        SearchCriteriaBuilder       $searchCriteriaBuilder,
        ResourceConnection          $resource,
        LoggerInterface             $logger
    ) {
        $this->customerRepository    = $customerRepository;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->resource              = $resource;
        $this->logger                = $logger;
    }

    // =========================================================================
    // PUBLIC API
    // =========================================================================

    /**
     * Called when a tier is DISABLED or DELETED.
     *
     * Moves every customer on $disabledTierName down to the nearest lower
     * active tier, or clears the attribute if none exists.
     */
    public function reassignCustomersFromTier(string $disabledTierName): void
    {
        if ($disabledTierName === '') {
            return;
        }

        $disabledTierSpend = $this->getMinSpendForTier($disabledTierName);
        $fallbackTier      = $this->fetchNearestLowerActiveTier($disabledTierSpend, $disabledTierName);
        $affectedCustomers = $this->getCustomersOnTier($disabledTierName);

        if (empty($affectedCustomers)) {
            $this->logger->info(sprintf(
                '[LoyaltyProgram] TierReassign DISABLE: no customers on tier "%s".',
                $disabledTierName
            ));
            return;
        }

        $fallbackName = $fallbackTier ? $fallbackTier['loyalty_tier_name'] : '';

        foreach ($affectedCustomers as $customer) {
            try {
                $customer->setCustomAttribute('custom_customer_attribute', $fallbackName);
                $this->customerRepository->save($customer);

                $this->logger->info(sprintf(
                    '[LoyaltyProgram] TierReassign DISABLE: customer %d moved "%s" → "%s".',
                    (int) $customer->getId(),
                    $disabledTierName,
                    $fallbackName ?: '(none)'
                ));
            } catch (\Exception $e) {
                $this->logger->error(sprintf(
                    '[LoyaltyProgram] TierReassign DISABLE: failed for customer %d — %s',
                    (int) $customer->getId(),
                    $e->getMessage()
                ));
            }
        }

        $this->logger->info(sprintf(
            '[LoyaltyProgram] TierReassign DISABLE: %d customer(s) moved from "%s" → "%s".',
            count($affectedCustomers),
            $disabledTierName,
            $fallbackName ?: '(none)'
        ));
    }

    /**
     * Called when a tier is RE-ENABLED.
     *
     * Scans all customers currently sitting on tiers BELOW the re-enabled
     * tier. Any customer whose lifetime_spend meets or exceeds the re-enabled
     * tier's min_lifetime_spend is promoted back up to it.
     *
     * Returns the count of customers reassigned.
     */
    public function reassignCustomersToReenabledTier(string $reenabledTierName): int
    {
        if ($reenabledTierName === '') {
            return 0;
        }

        // Full row of the tier that was just re-enabled (now status=1 in DB).
        $reenabledTier = $this->fetchTierByName($reenabledTierName);
        if (!$reenabledTier) {
            $this->logger->error(sprintf(
                '[LoyaltyProgram] TierReassign ENABLE: tier "%s" not found in DB.',
                $reenabledTierName
            ));
            return 0;
        }

        $reenabledMinSpend = (int) $reenabledTier['min_lifetime_spend'];

        // Collect the names of ALL active tiers that sit BELOW the re-enabled
        // tier (their min_lifetime_spend < re-enabled tier's min_lifetime_spend).
        // Customers currently on those lower tiers are candidates for promotion.
        $lowerTierNames = $this->getActiveTierNamesBelow($reenabledMinSpend, $reenabledTierName);

        // Also include customers who have NO tier assigned (attribute is empty / null)
        // but whose spend qualifies — they may have been fully cleared on disable.
        $candidateCustomers = $this->getCustomersOnTiers($lowerTierNames);
        $untieredCandidates = $this->getCustomersWithNoTier();
        $allCandidates      = array_merge($candidateCustomers, $untieredCandidates);

        if (empty($allCandidates)) {
            $this->logger->info(sprintf(
                '[LoyaltyProgram] TierReassign ENABLE: no candidate customers found for tier "%s".',
                $reenabledTierName
            ));
            return 0;
        }

        $count = 0;

        foreach ($allCandidates as $customer) {
            $lifetimeSpend = $this->getCustomerLifetimeSpend($customer);

            // Only promote if the customer actually qualifies for the re-enabled tier.
            if ($lifetimeSpend < $reenabledMinSpend) {
                continue;
            }

            // Safety: make sure no HIGHER active tier already fits this customer
            // better (edge-case: multiple tiers re-enabled at once, or customer
            // spend crossed a higher active threshold separately).
            $bestTier = $this->fetchBestActiveTierForSpend($lifetimeSpend);
            $assignName = $bestTier ? $bestTier['loyalty_tier_name'] : $reenabledTierName;

            $currentTierName = $this->getCustomerCurrentTier($customer);
            if ($currentTierName === $assignName) {
                continue; // already on the correct tier, skip
            }

            try {
                $customer->setCustomAttribute('custom_customer_attribute', $assignName);
                $this->customerRepository->save($customer);
                $count++;

                $this->logger->info(sprintf(
                    '[LoyaltyProgram] TierReassign ENABLE: customer %d promoted "%s" → "%s" (spend: %.2f).',
                    (int) $customer->getId(),
                    $currentTierName ?: '(none)',
                    $assignName,
                    $lifetimeSpend
                ));
            } catch (\Exception $e) {
                $this->logger->error(sprintf(
                    '[LoyaltyProgram] TierReassign ENABLE: failed for customer %d — %s',
                    (int) $customer->getId(),
                    $e->getMessage()
                ));
            }
        }

        $this->logger->info(sprintf(
            '[LoyaltyProgram] TierReassign ENABLE: promoted %d customer(s) to tier "%s".',
            $count,
            $reenabledTierName
        ));

        return $count;
    }

    // =========================================================================
    // PRIVATE HELPERS
    // =========================================================================

    /** Fetch full tier row by name (any status). */
    private function fetchTierByName(string $tierName): ?array
    {
        $connection = $this->resource->getConnection();
        $table      = $this->resource->getTableName('loyalty_tiers');

        $row = $connection->fetchRow(
            $connection->select()
                ->from($table)
                ->where('loyalty_tier_name = ?', $tierName)
                ->limit(1)
        );

        return $row ?: null;
    }

    /**
     * Returns min_lifetime_spend for a named tier (active or inactive).
     * Returns PHP_INT_MAX if not found — safe fallback so lower-tier query
     * returns nothing.
     */
    private function getMinSpendForTier(string $tierName): int
    {
        $row = $this->fetchTierByName($tierName);
        return $row ? (int) $row['min_lifetime_spend'] : PHP_INT_MAX;
    }

    /**
     * Highest active tier whose min_lifetime_spend < $threshold and name
     * is not $excludeName. Used as the fallback when disabling a tier.
     */
    private function fetchNearestLowerActiveTier(int $threshold, string $excludeName): ?array
    {
        $connection = $this->resource->getConnection();
        $table      = $this->resource->getTableName('loyalty_tiers');

        $row = $connection->fetchRow(
            $connection->select()
                ->from($table)
                ->where('status = ?', 1)
                ->where('min_lifetime_spend < ?', $threshold)
                ->where('loyalty_tier_name != ?', $excludeName)
                ->order('min_lifetime_spend DESC')
                ->limit(1)
        );

        return $row ?: null;
    }

    /**
     * Returns the best (highest qualifying) ACTIVE tier for a given spend.
     * Used to resolve the exact tier a customer should land on when promoted.
     */
    private function fetchBestActiveTierForSpend(float $lifetimeSpend): ?array
    {
        $connection = $this->resource->getConnection();
        $table      = $this->resource->getTableName('loyalty_tiers');

        $row = $connection->fetchRow(
            $connection->select()
                ->from($table)
                ->where('status = ?', 1)
                ->where('min_lifetime_spend <= ?', $lifetimeSpend)
                ->order('min_lifetime_spend DESC')
                ->limit(1)
        );

        return $row ?: null;
    }

    /**
     * Returns names of all ACTIVE tiers below a given spend threshold.
     * These are the tiers customers may have been pushed down to.
     */
    private function getActiveTierNamesBelow(int $threshold, string $excludeName): array
    {
        $connection = $this->resource->getConnection();
        $table      = $this->resource->getTableName('loyalty_tiers');

        $rows = $connection->fetchAll(
            $connection->select()
                ->from($table, ['loyalty_tier_name'])
                ->where('status = ?', 1)
                ->where('min_lifetime_spend < ?', $threshold)
                ->where('loyalty_tier_name != ?', $excludeName)
        );

        return array_column($rows, 'loyalty_tier_name');
    }

    /**
     * Returns customer objects whose custom_customer_attribute matches the
     * given tier name exactly.
     *
     * @return \Magento\Customer\Api\Data\CustomerInterface[]
     */
    private function getCustomersOnTier(string $tierName): array
    {
        $searchCriteria = $this->searchCriteriaBuilder
            ->addFilter('custom_customer_attribute', $tierName, 'eq')
            ->create();

        return $this->customerRepository->getList($searchCriteria)->getItems();
    }

    /**
     * Returns customer objects whose custom_customer_attribute is one of the
     * given tier names. Returns [] if the name list is empty.
     *
     * @param  string[] $tierNames
     * @return \Magento\Customer\Api\Data\CustomerInterface[]
     */
    private function getCustomersOnTiers(array $tierNames): array
    {
        if (empty($tierNames)) {
            return [];
        }

        $searchCriteria = $this->searchCriteriaBuilder
            ->addFilter('custom_customer_attribute', $tierNames, 'in')
            ->create();

        return $this->customerRepository->getList($searchCriteria)->getItems();
    }

    /**
     * Returns customer objects with NO tier assigned (empty / null attribute).
     * These were fully cleared when their tier was disabled with no lower fallback.
     *
     * @return \Magento\Customer\Api\Data\CustomerInterface[]
     */
    private function getCustomersWithNoTier(): array
    {
        $searchCriteria = $this->searchCriteriaBuilder
            ->addFilter('custom_customer_attribute', '', 'eq')
            ->create();

        return $this->customerRepository->getList($searchCriteria)->getItems();
    }

    /** Reads the customer's lifetime_spend custom attribute safely. */
    private function getCustomerLifetimeSpend(\Magento\Customer\Api\Data\CustomerInterface $customer): float
    {
        $attr = $customer->getCustomAttribute('lifetime_spend');
        return $attr ? (float) $attr->getValue() : 0.0;
    }

    /** Reads the customer's current tier name safely. */
    private function getCustomerCurrentTier(\Magento\Customer\Api\Data\CustomerInterface $customer): string
    {
        $attr = $customer->getCustomAttribute('custom_customer_attribute');
        return $attr ? (string) $attr->getValue() : '';
    }
}
