<?php

namespace Icreative\LoyaltyProgram\Model;

use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Framework\App\ResourceConnection;
use Magento\SalesRule\Model\Coupon;
use Magento\SalesRule\Model\CouponFactory;
use Magento\SalesRule\Model\Rule;
use Magento\SalesRule\Model\RuleFactory;
use Magento\Store\Model\StoreManagerInterface;
use Psr\Log\LoggerInterface;

class LoyaltyCouponService
{
    private const COUPON_PREFIX = 'LOYAL_';
    private const RULE_NAME = 'Loyalty Discount';

    private $ruleFactory;
    private $couponFactory;
    private $customerRepository;
    private $resource;
    private $storeManager;
    private $logger;

    public function __construct(
        RuleFactory $ruleFactory,
        CouponFactory $couponFactory,
        CustomerRepositoryInterface $customerRepository,
        ResourceConnection $resource,
        StoreManagerInterface $storeManager,
        LoggerInterface $logger
    ) {
        $this->ruleFactory = $ruleFactory;
        $this->couponFactory = $couponFactory;
        $this->customerRepository = $customerRepository;
        $this->resource = $resource;
        $this->storeManager = $storeManager;
        $this->logger = $logger;
    }

    public function getCouponCodeForCustomer(
        int $customerId,
        ?int $websiteId = null,
        ?int $customerGroupId = null
    ): ?string {
        try {
            $customer = $this->customerRepository->getById($customerId);
            $tierData = $this->getCustomerTierData($customer);
            if (!$tierData) {
                $this->deactivateLoyaltyRule($customerId);
                return null;
            }

            $discount = (float) ($tierData['discount_amount'] ?? 0);
            if ($discount <= 0) {
                $this->deactivateLoyaltyRule($customerId);
                return null;
            }

            $websiteId = $websiteId ?: (int) $this->storeManager->getStore()->getWebsiteId();
            $storeId = (int) $this->storeManager->getStore()->getId();
            $customerGroupId = $customerGroupId ?: (int) $customer->getGroupId();
            $couponCode = $this->getCouponCode($customerId);
            $label = $this->buildLabel($tierData);

            $rule = $this->loadRuleByCouponCode($couponCode);
            if (!$rule->getId()) {
                $rule = $this->ruleFactory->create();
            }

            $rule->setName(self::RULE_NAME)
                ->setDescription(sprintf('Auto-generated loyalty coupon for customer %d.', $customerId))
                ->setIsActive(1)
                ->setWebsiteIds([$websiteId])
                ->setCustomerGroupIds([$customerGroupId])
                ->setCouponType(Rule::COUPON_TYPE_SPECIFIC)
                ->setCouponCode($couponCode)
                ->setUseAutoGeneration(0)
                ->setSimpleAction(Rule::BY_PERCENT_ACTION)
                ->setDiscountAmount($discount)
                ->setDiscountQty(null)
                ->setDiscountStep(0)
                ->setApplyToShipping(0)
                ->setStopRulesProcessing(1)
                ->setIsAdvanced(1)
                ->setSortOrder(0)
                ->setUsesPerCustomer(0)
                ->setUsesPerCoupon(0)
                ->setStoreLabels([0 => $label, $storeId => $label]);

            $rule->save();
            $this->saveCoupon($rule, $couponCode);

            return $couponCode;
        } catch (\Exception $e) {
            $this->logger->error('[LoyaltyProgram] Loyalty coupon error: ' . $e->getMessage());
            return null;
        }
    }

    public function isLoyaltyCoupon(?string $couponCode): bool
    {
        return is_string($couponCode) && str_starts_with($couponCode, self::COUPON_PREFIX);
    }

    private function getCouponCode(int $customerId): string
    {
        return self::COUPON_PREFIX . $customerId;
    }

    private function loadRuleByCouponCode(string $couponCode): Rule
    {
        /** @var Coupon $coupon */
        $coupon = $this->couponFactory->create();
        $coupon->loadByCode($couponCode);

        /** @var Rule $rule */
        $rule = $this->ruleFactory->create();
        if ($coupon->getId() && $coupon->getRuleId()) {
            $rule->load((int) $coupon->getRuleId());
        }

        return $rule;
    }

    private function saveCoupon(Rule $rule, string $couponCode): void
    {
        /** @var Coupon $coupon */
        $coupon = $this->couponFactory->create();
        $coupon->loadByCode($couponCode);
        $coupon->setRuleId((int) $rule->getId())
            ->setCode($couponCode)
            ->setIsPrimary(1)
            ->setUsageLimit(0)
            ->setUsagePerCustomer(0)
            ->setType(0);
        $coupon->save();
    }

    private function deactivateLoyaltyRule(int $customerId): void
    {
        $rule = $this->loadRuleByCouponCode($this->getCouponCode($customerId));
        if ($rule->getId() && (int) $rule->getIsActive() !== 0) {
            $rule->setIsActive(0);
            $rule->save();
        }
    }

    private function getCustomerTierData($customer)
    {
        $tierName = '';
        $tierAttribute = $customer->getCustomAttribute('custom_customer_attribute');
        if ($tierAttribute) {
            $tierName = trim((string) $tierAttribute->getValue());
        }

        if ($tierName) {
            $tierData = $this->fetchTierByName($tierName);
            if ($tierData) {
                return $tierData;
            }
        }

        return $this->fetchTierByLifetimeSpend($customer);
    }

    private function fetchTierByName(string $tierName)
    {
        $connection = $this->resource->getConnection();
        $table = $this->resource->getTableName('loyalty_tiers');

        $row = $connection->fetchRow(
            $connection->select()
                ->from($table)
                ->where('loyalty_tier_name = ?', $tierName)
                ->where('status = ?', 1)
                ->limit(1)
        );

        return $row ?: false;
    }

    private function fetchTierByLifetimeSpend($customer)
    {
        $attribute = $customer->getCustomAttribute('lifetime_spend');
        $lifetimeSpend = $attribute ? (float) $attribute->getValue() : 0.0;
        if ($lifetimeSpend <= 0) {
            return false;
        }

        $connection = $this->resource->getConnection();
        $table = $this->resource->getTableName('loyalty_tiers');

        $row = $connection->fetchRow(
            $connection->select()
                ->from($table)
                ->where('min_lifetime_spend <= ?', $lifetimeSpend)
                ->where('status = ?', 1)
                ->order('min_lifetime_spend DESC')
                ->limit(1)
        );

        return $row ?: false;
    }

    private function buildLabel(array $tierData): string
    {
        return (string) __(
            '%1 Program %2% Discount',
            $tierData['loyalty_tier_name'],
            (int) $tierData['discount_amount']
        );
    }
}
