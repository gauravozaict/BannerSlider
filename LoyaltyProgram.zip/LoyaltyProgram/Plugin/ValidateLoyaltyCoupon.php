<?php

namespace Icreative\LoyaltyProgram\Plugin;

use Icreative\LoyaltyProgram\Model\LoyaltyCouponService;
use Icreative\LoyaltyProgram\Model\UsageLimitValidator;
use Magento\Quote\Model\Quote\Address;
use Magento\SalesRule\Model\Rule;
use Magento\SalesRule\Model\Utility;

class ValidateLoyaltyCoupon
{
    private $loyaltyCouponService;
    private $usageLimitValidator;

    public function __construct(
        LoyaltyCouponService $loyaltyCouponService,
        UsageLimitValidator $usageLimitValidator
    ) {
        $this->loyaltyCouponService = $loyaltyCouponService;
        $this->usageLimitValidator  = $usageLimitValidator;
    }

    public function aroundCanProcessRule(
        Utility $subject,
        callable $proceed,
        Rule $rule,
        Address $address
    ): bool {
        $quote = $address->getQuote();
        $couponCode = (string) $quote->getCouponCode();

        if (!$this->loyaltyCouponService->isLoyaltyCoupon($couponCode)) {
            return $proceed($rule, $address);
        }

        $customerId = (int) $quote->getCustomerId();
        if (!$customerId || $couponCode !== 'LOYAL_' . $customerId) {
            return false;
        }

        $validCouponCode = $this->loyaltyCouponService->getCouponCodeForCustomer(
            $customerId,
            (int) $quote->getStore()->getWebsiteId(),
            (int) $quote->getCustomerGroupId()
        );

        if ($validCouponCode !== $couponCode) {
            return false;
        }

        // Block the coupon discount when the customer's monthly usage limit is exhausted.
        if (!$this->usageLimitValidator->canApplyDiscount()) {
            return false;
        }

        return $proceed($rule, $address);
    }
}
