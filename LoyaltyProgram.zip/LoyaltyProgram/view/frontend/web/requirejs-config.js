
var config = {
    map: {
        '*': {
            'Icreative_LoyaltyProgram/js/view/custom-discount':
                'Icreative_LoyaltyProgram/js/view/custom-discount'
        }
    }
};
