define([
    'jquery',
    'ko',
    'Magento_Checkout/js/model/quote',
    'Magento_SalesRule/js/action/set-coupon-code',
    'Magento_SalesRule/js/action/cancel-coupon',
    'Magento_Checkout/js/action/get-totals',
    'Magento_SalesRule/js/model/coupon',
    'domReady!'
], function ($, ko, quote, setCouponCodeAction, cancelCouponAction, getTotalsAction, coupon) {
    'use strict';

    return function (config) {
        var couponCode = config.couponCode || '',
            removeCoupon = !!config.removeCoupon,
            isApplied = coupon.getIsApplied(),
            isRunning = false,
            currentCouponCode,
            applyCoupon,
            removeLoyaltyCoupon;

        currentCouponCode = function () {
            var totals = quote.getTotals();

            return totals() && totals()['coupon_code'] ? totals()['coupon_code'] : '';
        };

        applyCoupon = function () {
            if (!couponCode || isRunning || currentCouponCode() === couponCode) {
                return;
            }

            isRunning = true;
            setCouponCodeAction(couponCode, isApplied).done(function () {
                getTotalsAction([]);
            }).always(function () {
                isRunning = false;
            });
        };

        removeLoyaltyCoupon = function () {
            if (!removeCoupon || isRunning || currentCouponCode().indexOf('LOYAL_') !== 0) {
                return;
            }

            isRunning = true;
            cancelCouponAction(isApplied).done(function () {
                getTotalsAction([]);
            }).always(function () {
                isRunning = false;
            });
        };

        if (couponCode) {
            applyCoupon();
        } else {
            removeLoyaltyCoupon();
        }

        if (ko.isObservable(quote.getTotals())) {
            quote.getTotals().subscribe(function () {
                if (couponCode) {
                    applyCoupon();
                } else {
                    removeLoyaltyCoupon();
                }
            });
        }
    };
});
