<?php
namespace Icreative\LoyaltyProgram\Block;

use Magento\Framework\View\Element\Template;
use Magento\Framework\App\ResourceConnection;

class LoyaltyTier extends Template
{
    protected $resource;

    public function __construct(
        Template\Context $context,
        ResourceConnection $resource,
        array $data = []
    ) {
        $this->resource = $resource;
        parent::__construct($context, $data);
    }

    public function getCustomTableData()
    {
        $connection = $this->resource->getConnection();
        $tableName = $this->resource->getTableName('loyalty_tiers');
        
        $select = $connection->select()->from($tableName);
        return $connection->fetchAll($select);
    }
}

