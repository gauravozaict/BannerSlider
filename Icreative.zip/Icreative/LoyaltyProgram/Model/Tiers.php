<?php
namespace Icreative\LoyaltyProgram\Model;

use  \Magento\Framework\Model\AbstractModel;

class Tiers extends AbstractModel
{
    
    public function _construct()
    {
        $this->_init(\Icreative\LoyaltyProgram\Model\ResourceModel\Tiers::class);
    }
    
}