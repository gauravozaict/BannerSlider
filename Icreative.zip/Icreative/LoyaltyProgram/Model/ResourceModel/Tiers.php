<?php
namespace Icreative\LoyaltyProgram\Model\ResourceModel;

class Tiers extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    
    public function _construct()
    {
        $this->_init("loyalty_tiers", "loyalty_tier_id");
    }
}