<?php

namespace Icreative\LoyaltyProgram\Ui\Component\Listing\Column;

use Magento\Ui\Component\Listing\Columns\Column;
use Magento\Framework\UrlInterface;

class LoyaltyActions extends Column
{
    const URL_PATH_EDIT = 'loyaltyprogram/tier/edit';
    const URL_PATH_DELETE = 'loyaltyprogram/tier/delete';

    protected $urlBuilder;

    public function __construct(
        UrlInterface $urlBuilder,
        \Magento\Framework\View\Element\UiComponent\ContextInterface $context,
        \Magento\Framework\View\Element\UiComponentFactory $uiComponentFactory,
        array $components = [],
        array $data = []
    ) {
        $this->urlBuilder = $urlBuilder;

        parent::__construct(
            $context,
            $uiComponentFactory,
            $components,
            $data
        );
    }

    public function prepareDataSource(array $dataSource)
    {
        if (isset($dataSource['data']['items'])) {

            foreach ($dataSource['data']['items'] as & $item) {

                if (isset($item['loyalty_tier_id'])) {

                    $item[$this->getData('name')]['edit'] = [
                        'href' => $this->urlBuilder->getUrl(
                            self::URL_PATH_EDIT,
                            ['loyalty_tier_id' => $item['loyalty_tier_id']]
                        ),
                        'label' => __('Edit')
                    ];

                    $item[$this->getData('name')]['delete'] = [
                        'href' => $this->urlBuilder->getUrl(
                            self::URL_PATH_DELETE,
                            ['loyalty_tier_id' => $item['loyalty_tier_id']]
                        ),
                        'label' => __('Delete'),
                        'confirm' => [
                            'title' => __('Delete Tiers'),
                            'message' => __('Are you sure you want to delete selected items?')
                        ]
                    ];
                }
            }
        }

        return $dataSource;
    }
}