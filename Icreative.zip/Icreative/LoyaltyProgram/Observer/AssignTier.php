<?php
namespace Icreative\LoyaltyProgram\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\App\ResourceConnection;
use Magento\Customer\Api\CustomerRepositoryInterface;

class AssignTier implements ObserverInterface
{
    protected $resource;
    protected $customerRepository;

    public function __construct(
        ResourceConnection $resource,
        CustomerRepositoryInterface $customerRepository
    ) {
        $this->resource = $resource;
        $this->customerRepository = $customerRepository;
    }

    public function execute(Observer $observer)
    {
        $customerModel = $observer->getEvent()->getCustomer(); 
        
        if (!$customerModel || !$customerModel->getId()) {
            return;
        }

        $lifetimeSpend = $customerModel->getData('lifetime_spend') ?: 0;
        $connection = $this->resource->getConnection();
        $tableName = $this->resource->getTableName('loyalty_tiers');

        $select = $connection->select()
            ->from($tableName)
            ->where('min_lifetime_spend <= ?', $lifetimeSpend)
            ->order('min_lifetime_spend DESC')
            ->limit(1);

        $tier = $connection->fetchRow($select);

        if ($tier) {
            $customer = $this->customerRepository->getById($customerModel->getId());
            
            $customer->setCustomAttribute('custom_customer_attribute', $tier['loyalty_tier_name']);
            
            $this->customerRepository->save($customer);
        }
    }
}
