<?php
namespace Icreative\LoyaltyProgram\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Event\Observer;
use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Sales\Model\ResourceModel\Order\CollectionFactory as OrderCollectionFactory;

class UpdateLifetimeSpend implements ObserverInterface
{
    protected $customerRepository;
    protected $orderCollectionFactory;

    public function __construct(
        CustomerRepositoryInterface $customerRepository,
        OrderCollectionFactory $orderCollectionFactory
    ) {
        $this->customerRepository = $customerRepository;
        $this->orderCollectionFactory = $orderCollectionFactory;
    }

    public function execute(Observer $observer)
    {
        $order = $observer->getEvent()->getOrder();
        $customerId = $order->getCustomerId();

        if (!$customerId || $order->getState() !== \Magento\Sales\Model\Order::STATE_COMPLETE) {
            return;
        }

        try {
            $orderCollection = $this->orderCollectionFactory->create();
            $orderCollection->addAttributeToFilter('customer_id', $customerId)
                ->addAttributeToFilter('state', \Magento\Sales\Model\Order::STATE_COMPLETE);
            
            $totalSpend = 0;
            foreach ($orderCollection as $completedOrder) {
                $totalSpend += $completedOrder->getGrandTotal();
            }

            $customer = $this->customerRepository->getById($customerId);
            $customer->setCustomAttribute('lifetime_spend', $totalSpend);
            
            $this->customerRepository->save($customer);
        } catch (\Exception $e) {
        }
    }
}
