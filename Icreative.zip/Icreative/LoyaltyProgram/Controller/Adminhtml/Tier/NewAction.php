<?php
namespace Icreative\LoyaltyProgram\Controller\Adminhtml\Tier;

use Magento\Backend\App\Action;
use Magento\Framework\Controller\ResultFactory;

class NewAction extends Action
{
    public const ADMIN_RESOURCE = 'Icreative_LoyaltyProgram::tier';

    public function execute()
    {
        return $this->resultFactory->create(ResultFactory::TYPE_PAGE);
    }
}