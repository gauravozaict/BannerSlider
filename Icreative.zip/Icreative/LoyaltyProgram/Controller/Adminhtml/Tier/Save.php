<?php

namespace Icreative\LoyaltyProgram\Controller\Adminhtml\Tier;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Icreative\LoyaltyProgram\Model\TiersFactory;

class Save extends Action
{
    public const ADMIN_RESOURCE = 'Icreative_LoyaltyProgram::tier';

    private const ALLOWED_FIELDS = [
        'loyalty_tier_id',
        'loyalty_tier_name',
        'discount_amount',
        'usage_limit',
        'min_lifetime_spend',
    ];

    protected TiersFactory $tierFactory;

    public function __construct(
        Context $context,
        TiersFactory $tierFactory
    ) {
        parent::__construct($context);
        $this->tierFactory = $tierFactory;
    }

    public function execute()
    {
        $postData = $this->getRequest()->getPostValue();

        if (empty($postData)) {
            $this->messageManager->addErrorMessage(__('No data received.'));
            return $this->_redirect('*/*/');
        }

        try {
           
            $data = $this->flattenPostData($postData);

            
            if (isset($data['image'])) {
                $data['image'] = $this->resolveImageValue($data['image']);
            }

            
            $data = array_intersect_key($data, array_flip(self::ALLOWED_FIELDS));

            
            $data = $this->castScalars($data);

            $model = $this->tierFactory->create();

            if (!empty($data['loyalty_tier_id'])) {
                $model->load((int)$data['loyalty_tier_id']);
                if (!$model->getId()) {
                    $this->messageManager->addErrorMessage(__('This tier no longer exists.'));
                    return $this->_redirect('*/*/');
                }
            }

            $model->setData($data);
            $model->save();

            $this->messageManager->addSuccessMessage(__('Tier has been saved successfully.'));

            
            if (!empty($data['loyalty_tier_id'])) {
                return $this->_redirect('*/*/edit', ['loyalty_tier_id' => $model->getId()]);
            }

            return $this->_redirect('*/*/');

        } catch (\Exception $e) {
            $this->messageManager->addErrorMessage(__('Could not save Tier: %1', $e->getMessage()));
            return $this->_redirect('*/*/');
        }
    }

   
    private function flattenPostData(array $postData): array
    {
        $flat = [];
        foreach ($postData as $key => $value) {
            if (is_array($value) && $this->isAssoc($value)) {
                $firstVal = reset($value);
                if (!isset($value['name']) && !isset($value['url'])) {
                    foreach ($value as $fieldKey => $fieldValue) {
                        $flat[$fieldKey] = $fieldValue;
                    }
                    continue;
                }
            }
            $flat[$key] = $value;
        }
        return $flat;
    }

   
    private function resolveImageValue(mixed $imageData): string
    {
        if (is_string($imageData)) {
            return $imageData;
        }

        if (is_array($imageData)) {
            if (empty($imageData)) {
                return '';
            }
            $first = reset($imageData);
            if (is_array($first)) {
                return $first['name'] ?? $first['file'] ?? '';
            }
            return (string)$first;
        }

        return '';
    }

   
    private function castScalars(array $data): array
    {
        foreach ($data as $key => $value) {
            if (is_array($value)) {
                $data[$key] = json_encode($value);
            } elseif ($value === null || $value === '') {
                $data[$key] = null;
            }
        }
        return $data;
    }

    private function isAssoc(array $arr): bool
    {
        return array_keys($arr) !== range(0, count($arr) - 1);
    }
}