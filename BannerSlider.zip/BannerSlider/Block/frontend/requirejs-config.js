var config = {
    paths: {
        owlcarousel: 'Icreative_BannerSlider/js/owl.carousel.min',
    },
    shim: {
        owlcarousel: {
            deps: ['jquery']
        }
    },
    map:{
        '*': {
            'slider': 'Icreative_BannerSlider/js/slider'
        }
    }
};