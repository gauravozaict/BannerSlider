define([
   'jquery',
   'owlcarousel'
], function ($) {
   'use strict';


   return function () {
	//Owl Carousel
	$(".all-banner-slide").owlCarousel({
		items: 1,
		smartSpeed: 1000,
		autoplay: true,
		lazyLoad: true,
		dots: false,
		autoplayTimeout: 3000
	});
 
};
});
