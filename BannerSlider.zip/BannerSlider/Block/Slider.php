<?php

namespace Icreative\BannerSlider\Block;

use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
use Icreative\BannerSlider\Model\ResourceModel\Banner\CollectionFactory;
use Magento\Store\Model\StoreManagerInterface;

class Slider extends Template
{
    /**
     * @var CollectionFactory
     */
    protected $collectionFactory;

    /**
     * @var StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @param Context $context
     * @param CollectionFactory $collectionFactory
     * @param array $data
     */
    public function __construct(
        Context $context,
        CollectionFactory $collectionFactory,
        array $data = []
    ) {
        $this->collectionFactory = $collectionFactory;
        $this->storeManager = $context->getStoreManager();
        parent::__construct($context, $data);
    }

    /**
     * Get enabled banners collection
     *
     * @return \Icreative\BannerSlider\Model\ResourceModel\Banner\Collection
     */
    public function getBannerCollection()
    {
        $collection = $this->collectionFactory->create();
        $collection->addFieldToFilter('status', 1);
        $collection->setOrder('sort_order', 'ASC');
        return $collection;
    }

    /**
     * Get banner image URL
     *
     * @param string $imagePath
     * @return string
     */
    public function getImageUrl($imagePath)
    {
        if (!$imagePath) {
            return '';
        }
        return $this->storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA) . 'icreative/bannerslider/' . $imagePath;
    }
}
