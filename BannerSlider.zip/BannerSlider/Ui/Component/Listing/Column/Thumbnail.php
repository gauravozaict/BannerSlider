<?php

namespace Icreative\BannerSlider\Ui\Component\Listing\Column;

use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Ui\Component\Listing\Columns\Column;

class Thumbnail extends Column
{
    protected $storeManager;

    public function __construct(
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        StoreManagerInterface $storeManager,
        array $components = [],
        array $data = []
    ) {
        $this->storeManager = $storeManager;
        parent::__construct($context, $uiComponentFactory, $components, $data);
    }

    public function prepareDataSource(array $dataSource)
    {
        if (isset($dataSource['data']['items'])) {
            $fieldName = $this->getData('name');
            foreach ($dataSource['data']['items'] as & $item) {
                if (isset($item['image']) && $item['image']) {
                    $url = $this->storeManager->getStore()->getBaseUrl(
                        \Magento\Framework\UrlInterface::URL_TYPE_MEDIA
                    ) . 'icreative/bannerslider/' . $item['image'];
                    $item[$fieldName . '_src'] = $url;
                    $item[$fieldName . '_alt'] = $item['title'] ?? '';
                    $item[$fieldName . '_link'] = $this->context->getUrl(
                        'bannerslider/banner/edit',
                        ['banner_id' => $item['banner_id']]
                    );
                    $item[$fieldName . '_orig_src'] = $url;
                }
            }
        }

        return $dataSource;
    }
}
