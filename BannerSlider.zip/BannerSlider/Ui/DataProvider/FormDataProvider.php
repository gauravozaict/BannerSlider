<?php

namespace Icreative\BannerSlider\Ui\DataProvider;

use Magento\Ui\DataProvider\AbstractDataProvider;
use Magento\Framework\App\RequestInterface;
use Icreative\BannerSlider\Model\ResourceModel\Banner\CollectionFactory;

class FormDataProvider extends AbstractDataProvider
{
    protected $loadedData;
    protected RequestInterface $request;

    public function __construct(
        string $name,
        string $primaryFieldName,
        string $requestFieldName,
        CollectionFactory $collectionFactory,
        RequestInterface $request,
        array $meta = [],
        array $data = []
    ) {
        $this->collection = $collectionFactory->create();
        $this->request    = $request;
        parent::__construct(
            $name,
            $primaryFieldName,
            $requestFieldName,
            $meta,
            $data
        );
    }

    public function getData(): array
    {
        // Return cached result if already loaded
        if ($this->loadedData !== null) {
            return $this->loadedData;
        }

        $this->loadedData = [];

        // Only populate data when editing an existing banner
        $bannerId = $this->request->getParam('banner_id');
        if ($bannerId) {
            $banner = $this->collection->getItemById($bannerId);
            if ($banner) {
                $this->loadedData[$bannerId] = $banner->getData();
            }
        }

        return $this->loadedData;
    }
}
