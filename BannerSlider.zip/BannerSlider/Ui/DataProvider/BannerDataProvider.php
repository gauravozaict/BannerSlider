<?php

namespace Icreative\BannerSlider\Ui\DataProvider;

use Magento\Ui\DataProvider\AbstractDataProvider;
use Icreative\BannerSlider\Model\ResourceModel\Banner\CollectionFactory;

class BannerDataProvider extends AbstractDataProvider
{
    public function __construct(
        string $name,
        string $primaryFieldName,
        string $requestFieldName,
        CollectionFactory $collectionFactory,
        array $meta = [],
        array $data = []
    ) {
        $this->collection = $collectionFactory->create();

        parent::__construct(
            $name,
            $primaryFieldName,
            $requestFieldName,
            $meta,
            $data
        );
    }

    public function getData()
    {
        return [
            'totalRecords' => $this->collection->getSize(),
            'items' => array_values($this->collection->toArray()['items'])
        ];
    }
}