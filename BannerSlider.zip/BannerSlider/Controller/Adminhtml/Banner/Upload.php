<?php

namespace Icreative\BannerSlider\Controller\Adminhtml\Banner;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Controller\ResultFactory;
use Magento\MediaStorage\Model\File\UploaderFactory;
use Magento\Framework\Filesystem;
use Magento\Framework\App\Filesystem\DirectoryList;

class Upload extends Action
{
    public const ADMIN_RESOURCE = 'Icreative_BannerSlider::banner';

    protected UploaderFactory $uploaderFactory;
    protected Filesystem $filesystem;

    public function __construct(
        Context $context,
        UploaderFactory $uploaderFactory,
        Filesystem $filesystem
    ) {
        parent::__construct($context);
        $this->uploaderFactory = $uploaderFactory;
        $this->filesystem      = $filesystem;
    }

    public function execute()
    {
        $result = $this->resultFactory->create(ResultFactory::TYPE_JSON);

        try {
            $uploader = $this->uploaderFactory->create(['fileId' => 'image']);
            $uploader->setAllowedExtensions(['jpg', 'jpeg', 'gif', 'png']);
            $uploader->setAllowRenameFiles(true);
            $uploader->setFilesDispersion(false);

            $mediaDir = $this->filesystem->getDirectoryWrite(DirectoryList::MEDIA);
            $uploadDir = $mediaDir->getAbsolutePath('icreative/bannerslider');

            $uploadResult = $uploader->save($uploadDir);
            $uploadResult['url'] = 'icreative/bannerslider/' . $uploadResult['file'];

            $result->setData($uploadResult);
        } catch (\Exception $e) {
            $result->setData(['error' => $e->getMessage(), 'errorcode' => $e->getCode()]);
        }

        return $result;
    }
}
