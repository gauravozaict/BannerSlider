<?php

namespace Icreative\BannerSlider\Controller\Adminhtml\Banner;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Icreative\BannerSlider\Model\BannerFactory;

class Save extends Action
{
    public const ADMIN_RESOURCE = 'Icreative_BannerSlider::banner';

    // DB columns that are allowed to be saved — must match db_schema.xml exactly
    private const ALLOWED_FIELDS = [
        'banner_id',
        'title',
        'link',
        'image',
        'status',
        'sort_order',
    ];

    protected BannerFactory $bannerFactory;

    public function __construct(
        Context $context,
        BannerFactory $bannerFactory
    ) {
        parent::__construct($context);
        $this->bannerFactory = $bannerFactory;
    }

    public function execute()
    {
        // The UI form posts data inside a "general" key that mirrors the fieldset name
        $postData = $this->getRequest()->getPostValue();

        if (empty($postData)) {
            $this->messageManager->addErrorMessage(__('No data received.'));
            return $this->_redirect('*/*/');
        }

        try {
            // UI components nest field values under the fieldset name ("general")
            // Flatten them into a single-level array
            $data = $this->flattenPostData($postData);

            // Resolve the image field — the image uploader sends an array like:
            // [['name' => 'file.jpg', 'url' => '...', ...]]
            // We only want to store the filename string
            if (isset($data['image'])) {
                $data['image'] = $this->resolveImageValue($data['image']);
            }

            // Strip any keys that are not real DB columns to prevent
            // "Array to string conversion" from stray UI component payloads
            $data = array_intersect_key($data, array_flip(self::ALLOWED_FIELDS));

            // Cast scalar fields so nothing slips through as an array
            $data = $this->castScalars($data);

            $model = $this->bannerFactory->create();

            if (!empty($data['banner_id'])) {
                $model->load((int)$data['banner_id']);
                if (!$model->getId()) {
                    $this->messageManager->addErrorMessage(__('This banner no longer exists.'));
                    return $this->_redirect('*/*/');
                }
            }

            $model->setData($data);
            $model->save();

            $this->messageManager->addSuccessMessage(__('Banner has been saved successfully.'));

            // Redirect to edit page so the user can continue editing
            if (!empty($data['banner_id'])) {
                return $this->_redirect('*/*/edit', ['banner_id' => $model->getId()]);
            }

            return $this->_redirect('*/*/');

        } catch (\Exception $e) {
            $this->messageManager->addErrorMessage(__('Could not save banner: %1', $e->getMessage()));
            return $this->_redirect('*/*/');
        }
    }

    /**
     * UI form data arrives nested under fieldset names, e.g.:
     *   ['general' => ['title' => 'Foo', 'image' => [...]], 'banner_id' => '5']
     * Merge all nested arrays into the top-level array.
     */
    private function flattenPostData(array $postData): array
    {
        $flat = [];
        foreach ($postData as $key => $value) {
            if (is_array($value) && $this->isAssoc($value)) {
                // Check if this looks like a fieldset group (all-array values),
                // not a file/image array (which has 'name', 'url' etc. keys)
                $firstVal = reset($value);
                if (!isset($value['name']) && !isset($value['url'])) {
                    // Fieldset group — merge one level deep
                    foreach ($value as $fieldKey => $fieldValue) {
                        $flat[$fieldKey] = $fieldValue;
                    }
                    continue;
                }
            }
            $flat[$key] = $value;
        }
        return $flat;
    }

    /**
     * The image uploader sends one of:
     *   - An array of file objects: [['name'=>'x.jpg','url'=>'...'], ...]
     *   - A plain string (already processed / existing value)
     *   - An empty array (field was cleared)
     * We extract just the filename string, or empty string if cleared.
     */
    private function resolveImageValue(mixed $imageData): string
    {
        if (is_string($imageData)) {
            return $imageData;
        }

        if (is_array($imageData)) {
            if (empty($imageData)) {
                return '';
            }
            // File objects array — grab the first entry's 'name' or 'file' key
            $first = reset($imageData);
            if (is_array($first)) {
                return $first['name'] ?? $first['file'] ?? '';
            }
            // Flat array with direct string values
            return (string)$first;
        }

        return '';
    }

    /**
     * Ensure every value destined for the DB is a scalar.
     * Any remaining arrays get JSON-encoded rather than causing a fatal.
     */
    private function castScalars(array $data): array
    {
        foreach ($data as $key => $value) {
            if (is_array($value)) {
                // Fallback safety net — should not reach here after filtering
                $data[$key] = json_encode($value);
            } elseif ($value === null || $value === '') {
                $data[$key] = null;
            }
        }
        return $data;
    }

    private function isAssoc(array $arr): bool
    {
        return array_keys($arr) !== range(0, count($arr) - 1);
    }
}