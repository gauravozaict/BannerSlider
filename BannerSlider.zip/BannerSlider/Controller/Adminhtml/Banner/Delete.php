<?php

namespace Icreative\BannerSlider\Controller\Adminhtml\Banner;

use Magento\Backend\App\Action;
use Icreative\BannerSlider\Model\BannerFactory;

class Delete extends Action
{
    protected $bannerFactory;

    public function __construct(
        Action\Context $context,
        BannerFactory $bannerFactory
    ) {
        parent::__construct($context);
        $this->bannerFactory = $bannerFactory;
    }

    public function execute()
    {
        $id = $this->getRequest()->getParam('banner_id');

        if ($id) {
            $model = $this->bannerFactory->create()->load($id);
            $model->delete();

            $this->messageManager->addSuccessMessage(__('Banner Deleted'));
        }

        return $this->_redirect('*/*/index');
    }
}