<?php

namespace Icreative\BannerSlider\Controller\Adminhtml\Banner;

use Magento\Framework\Controller\ResultFactory;

class MassDisable extends AbstractMassAction
{
    /**
     * @param \Icreative\BannerSlider\Model\ResourceModel\Banner\Collection $collection
     * @return \Magento\Backend\Model\View\Result\Redirect
     */
    protected function massAction($collection)
    {
        $count = 0;
        foreach ($collection as $item) {
            $item->setStatus(0);
            $item->save();
            $count++;
        }

        $this->messageManager->addSuccessMessage(__('A total of %1 record(s) have been disabled.', $count));

        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
        return $resultRedirect->setPath('*/*/index');
    }
}
