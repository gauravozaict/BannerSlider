<?php

namespace Icreative\BannerSlider\Controller\Adminhtml\Banner;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Icreative\BannerSlider\Model\BannerFactory;
use Magento\Framework\Registry;

class Edit extends Action
{
    public const ADMIN_RESOURCE = 'Icreative_BannerSlider::banner';

    protected PageFactory $resultPageFactory;
    protected BannerFactory $bannerFactory;
    protected Registry $coreRegistry;

    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,
        BannerFactory $bannerFactory,
        Registry $coreRegistry
    ) {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
        $this->bannerFactory     = $bannerFactory;
        $this->coreRegistry      = $coreRegistry;
    }

    public function execute()
    {
        $bannerId = (int)$this->getRequest()->getParam('banner_id');
        $banner   = $this->bannerFactory->create();

        if ($bannerId) {
            $banner->load($bannerId);
            if (!$banner->getId()) {
                $this->messageManager->addErrorMessage(__('This banner no longer exists.'));
                return $this->resultRedirectFactory->create()->setPath('*/*/');
            }
        }

        // Register current banner model so blocks / data providers can access it
        $this->coreRegistry->register('current_banner', $banner);

        $resultPage = $this->resultPageFactory->create();
        $resultPage->setActiveMenu('Icreative_BannerSlider::banner');

        $title = $bannerId ? __('Edit Banner') : __('Add New Banner');
        $resultPage->getConfig()->getTitle()->prepend($title);

        return $resultPage;
    }
}
