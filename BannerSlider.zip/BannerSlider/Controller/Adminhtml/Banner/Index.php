<?php
namespace Icreative\BannerSlider\Controller\Adminhtml\Banner;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;

class Index extends Action
{
    
    protected $context;

   
    protected $resultPageFactory;

    
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory
    ) {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
    }

    public function execute()
    {
        $resultPage = $this->resultPageFactory->create();
        $resultPage->setActiveMenu('Icreative_BannerSlider::banner');
        $resultPage->getConfig()->getTitle()->prepend(__('Manage Banners'));
        return $resultPage;
    }

    
    public function _isAllowed()
    {
        return $this->_authorization->isAllowed('Icreative_BannerSlider::banner');
    }
}