<?php

namespace Icreative\BannerSlider\Model;

use Magento\Framework\Model\AbstractModel;

class Banner extends AbstractModel
{
    protected function _construct()
    {
        $this->_init(\Icreative\BannerSlider\Model\ResourceModel\Banner::class);
    }
}