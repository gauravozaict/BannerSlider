<?php

namespace Icreative\BannerSlider\Model\ResourceModel;
// Abstract class stores CRUD operations method to db oprations
use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

class Banner extends AbstractDb
{
    protected function _construct()
    {
        $this->_init('icreative_banner', 'banner_id');
    }
}