<?php

namespace Icreative\BannerSlider\Model\ResourceModel\Banner;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{
    protected function _construct()
    {
        $this->_init(
            \Icreative\BannerSlider\Model\Banner::class,
            \Icreative\BannerSlider\Model\ResourceModel\Banner::class
        );
    }
}