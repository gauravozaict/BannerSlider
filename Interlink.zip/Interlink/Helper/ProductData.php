<?php

namespace Icreative\Interlink\Helper;


class ProductData extends \Magento\Framework\App\Helper\AbstractHelper
{
    protected $productFactory;
	
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Magento\Catalog\Model\ProductFactory $productFactory,
        array $data = []
    ) {
        parent::__construct($context);
        $this->productFactory = $productFactory;
    }

    public function getProductBySku($sku)
    {
        $product = $this->productFactory->create();
        $productdata = $product->loadByAttribute('sku', $sku);
        return $productdata;
    }

    public function getLinkedProduct($sku)
    {
        $product = $this->productFactory->create();
        $productdata = $product->loadByAttribute('linked_skus', $sku);
        return $productdata;
    }
}