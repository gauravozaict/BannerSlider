<?php

namespace Icreative\Interlink\Model;

use Magento\Catalog\Model\Product;

class TierPricing
{
    public function getApplicableTierPrice(Product $product, $quantity)
    {
        $allTierPrices = $product->getTierPrices();

        if (empty($allTierPrices)) {
            return (float) $product->getPrice();
        }

        usort($allTierPrices, function ($firstTier, $secondTier) {
            return (int) $firstTier->getQty() - (int) $secondTier->getQty();
        });

        $finalPrice = (float) $product->getPrice();

        foreach ($allTierPrices as $currentTierPrice) {
            $tierQuantity = (int) $currentTierPrice->getQty();
            $tierPriceValue = (float) $currentTierPrice->getValue();

            if ($quantity >= $tierQuantity) {
                $finalPrice = $tierPriceValue;
            } else {
                break;
            }
        }

        return $finalPrice;
    }
}
