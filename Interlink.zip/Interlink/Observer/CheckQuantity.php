<?php

namespace Icreative\Interlink\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Psr\Log\LoggerInterface;

class CheckQuantity implements ObserverInterface
{
    protected $logger;
    
    public function __construct(
        LoggerInterface $logger
    ) {
        $this->logger = $logger;
    }
   
    public function execute(Observer $observer)
    {
        try {
            $cartData = $observer->getEvent()->getCartData();
            
            if ($cartData) {
                $this->logger->info('Interlink - Cart items updated: ' . json_encode($cartData));
            }

        } catch (\Exception $e) {
            $this->logger->error('Error in CheckQuantity: ' . $e->getMessage());
        }
        
        return;
    }
}