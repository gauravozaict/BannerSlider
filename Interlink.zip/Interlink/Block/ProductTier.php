<?php

namespace Icreative\Interlink\Block;

class ProductTier extends \Magento\Framework\View\Element\Template
{   
    /*Product collection variable*/ 
    protected $_productCollection;

    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,        
        \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollection,       
        array $data = []
    )
    {    
        $this->_productCollection= $productCollection;    
        parent::__construct($context, $data);
    }
    
    public function getProductCollection()
    {

        $collection = $this->_productCollection->create();
        $collection->addAttributeToSelect('*');
        $collection->addAttributeToFilter('status',\Magento\Catalog\Model\Product\Attribute\Source\Status::STATUS_ENABLED);

        return $collection;
    }
}
